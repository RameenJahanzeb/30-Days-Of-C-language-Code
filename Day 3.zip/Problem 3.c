/*Write a program that generates two random numbers. First number should be in the range[10,99] and second number 
should be less than first number. Then it, checks whether their sum is even or odd and prints out the result.*/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(){
	int sum;
	    srand(time(0));
	int num1=rand()%90+10;
	 int num2=rand()%num1+1;
	 
	 printf(" Two random numbers: %d %d\n",num1,num2);
	 sum=num1+num2;
	 if(sum%2==0){
	 	printf(" Their sum is even.\n");
	 }
	 else{
	 	printf(" Their sum is odd.");
	 }
	 return 0; 
}
