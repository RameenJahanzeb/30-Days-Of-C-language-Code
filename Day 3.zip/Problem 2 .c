/*Write a program that takes three angles(positive numbers) of a 
triangle from user and prints �Yes, such triangle is possible� if 
sum of all angles is 180 degrees, otherwise prints �Sorry, Such 
triangle can�t exist�.*/

#include<stdio.h>
int main(){
	int angle1,angle2,angle3,sum;
	printf("Enter three angles of a triangle: ");
	scanf("%d %d %d",&angle1,&angle2,&angle3);
	 
	 sum=angle1+angle2+angle3;
	 if(sum==180){
	 printf("Yes, such triangle is possible");
	 }
	 else{
	 	printf("Sorry, Such triangle can't exist.");
	 }
	 return 0;
}
	
	
