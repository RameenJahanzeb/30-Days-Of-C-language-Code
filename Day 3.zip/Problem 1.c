/*Write a program that takes three numbers from user and prints all 
numbers are same if they are equal ,otherwise prints the largest 
and smallest number among them.*/

#include<stdio.h>
int main(){
	int num1,num2,num3,min,max;
	printf("Enter three numbers: ");
	scanf("%d %d %d",&num1, &num2, &num3);
	
	if(num1==num2 && num1==num3 && num3==num2){
		printf("All numbers are same.\n");
	}
	else{
		if(num1<num2 && num1<num3){
			min=num1;
		}
		if(num2<num1 && num2<num3){
			min=num2;
		}
	    if(num3<num1 && num3<num2){
			min=num3;
		}
		if(num1>num2 && num1>num3){
			max=num1;
		}
		if(num2>num1 && num2>num3){
			max=num2;
		}
		if(num3>num1 && num3>num2){
			max=num3;
		}
       printf("Smallest Number: %d\n",min);
       printf("Largest Number: %d",max);
}
    return 0;
}
