//Write a program in C that checks whether number entered by user is even or odd using Bitwise operators.
 
 #include<stdio.h>
int main(){
	int num;
	
	printf(" Enter the number: ");
	scanf("%d",&num);
	
	if((num&1)==0){
		printf(" %d is an even number.",num);
	}
	else{
		printf(" %d is a odd number.",num);
	}
	return 0;
}
