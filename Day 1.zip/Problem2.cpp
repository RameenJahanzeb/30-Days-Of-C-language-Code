#include<stdio.h>
int main(){
	printf("This is master in ''C language'' 30 days course.\n This course is organized by TECH INVOLVERS.");
	return 0;
}
