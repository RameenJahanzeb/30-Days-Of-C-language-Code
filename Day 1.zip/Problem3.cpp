#include<stdio.h>
int main(){
	printf(" _______\n");
	printf("|\n");
	printf(" _______\n");
	printf("|\n");
	printf(" _______");
}
