#include<stdio.h>
int main(){
	printf(" _____                                    _____\n");
	printf("|     | >>-----------------------------<<|     |\n");
	printf(" _____                                    _____\n\n");
	printf("|----->\t\t\t\t\t <-----|\n");
	printf("|------------>\t\t\t  <------------|\n");
	printf("|----->\t\t\t\t\t <-----|\n");
	return 0;
} 
