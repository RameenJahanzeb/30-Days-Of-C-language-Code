//Write a C program to print Alphabet Triangle

#include <stdio.h>

int main() {
    int range;
    char alphabet = 'A';
    printf("Enter range: ");
    scanf("%d", &range);

    for (int i=0; i<range; i++) {
    	for (int j=0; j<range-i+1; j++){
    		printf(" ");
		}
        
        for (int j=0; j<=i; j++) {
            printf("%c", alphabet++);
        }
          alphabet--;
        for (int j=0; j<i; j++) {
            printf("%c", --alphabet);
            
        }
        printf("\n");
    }

    return 0;
}

