/*Write a program that get an input from the user and check whether number is
palindrome or not.*/

#include<stdio.h>
int main(){
	int num,reverse=0,ans,num_rev;
	printf("Number: ");
	scanf("%d",&num);
	num_rev=num;
	while(num!=0){
		ans=num%10;
		reverse=reverse*10+ans;
		num=num/10;
	}
	if(num_rev==reverse){
		printf(" Palindrome Number");
	}
	else{
		printf(" Not a Palindrome Number");
	}
	return 0;
}
