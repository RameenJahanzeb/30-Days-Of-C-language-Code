//Write a program to check whether given number is Armstrong or not. 

#include<stdio.h>
int main(){
	int num,num_new,sum=0,rem;
	
	printf(" Enter Number: ");
	scanf("%d",&num);
	num_new=num;
	while(num!=0){
		rem=num%10;
		sum=sum+(rem*rem*rem);
		num=num/10;
	}
	if(num_new==sum){
		printf(" Yes, Armstrong Number");
	}
	else{
	printf(" Not an Armstrong Number");
	}
	return 0;
}
