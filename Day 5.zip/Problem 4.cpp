//Write a program that prints the following pattern. 

#include<stdio.h>
int main(){
	     //pattern a
	     printf("  (a)\n\n");
	for(int i=1; i<=5; i++){
		for(int j=1; j<=i; j++){
	      printf(" *");
        }
        printf("\n");
    }
       printf("\n\n");
       //pattern b
        printf("  (b)\n\n");
    for(int i=1; i<=5; i++){
	 for(int j=5; j>=i; j--){
	 	printf(" *");
	 }
	 printf("\n");
        }
	return 0;
}
