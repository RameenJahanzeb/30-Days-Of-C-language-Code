//Write a program to prints the first n terms of Fibonacci sequence where n is positive integer entered by user.

#include<stdio.h>
int main(){
	int num,a=0,b=1,c;
	
	printf("  Number of terms:");
	scanf("%d",&num);
	
	for(int i=1; i<=num; i++){
		
		printf(" %d",a);
		c=a+b;
		b=a;
		a=c;
	}
	return 0;
}
