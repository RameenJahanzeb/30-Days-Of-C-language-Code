/*Write a program that prints a table of binary, octal and
hexadecimal equivalent of decimal numbers in the
range(1-255).*/

#include<stdio.h>

void binary(int num){
	for (int i=7; i>=0; i--) {
        int binary=(num >> i) & 1;
        printf("%d",binary);
}}
int main(){
	int decimal;
	int octal,hexadecimal;
	
	printf("Decimal\t\tBinary\t\tOctal\t\tHexadecimal\n");
	for(int i=1; i<=255; i++){
		 printf("  \n%d",i);
         printf("\t        ");
          binary(i);
		  printf("\t  %o",i);
		  printf("\t\t     %X\t",i);
	}
        return 0;
}
