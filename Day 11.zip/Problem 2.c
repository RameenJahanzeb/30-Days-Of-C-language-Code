/*Write a program to takes input 2x2 matrix from user and
displays its determinants.*/

#include<stdio.h>
int main(){
	int arr[2][2],det;
	
	printf("Enter 2x2 matrix elements: ");
	for (int i=0; i<2; i++){
		
		for(int j=0; j<2; j++){
			scanf("  %d",&arr[i][j]);
		}
	}
	for(int i=0; i<2; i++){
		 printf("\n");
		 for (int j=0; j<2; j++){
		 	printf("  %d ",arr[i][j]);
		 }
	}
	  det=arr[0][0]*arr[1][1]-arr[0][1]*arr[1][0];
	  	printf("\n\nDeterminent: %d  ",det);
	  	return 0;
	  
}
