//Write a program to print the second maximum element in an array entered by user.


#include<stdio.h>
int main(){
	int n;
       printf("Enter list size : ");
	scanf("%d",&n);
	int arr[n];
	
	printf(" Enter %d numbers : ",n);
	for (int i=0; i<n; i++){
	scanf(" %d",&arr[i]);
      }
      int max1=arr[0];
      for(int i=0; i<n; i++){
      		if (arr[i]>max1){
      			max1=arr[i];
			  }
		}
		int max2=arr[0]; 
		for(int i=0; i<n; i++){
			  if(arr[i]!=max1 && arr[i]>max2){
			  	max2=arr[i];
			  }
		  }
	  
	  printf(" Second Maximum element : %d",max2);
}
