/*Write a program that scans for array from user and returns
the reverse array in place.(User defined function)*/


#include<stdio.h>
void reverse(int arr[],int n){

	for (int i=n-1; i>=0; i--){
		printf(" %d",arr[i]);
	}
}
int main(){
	int n;
       printf("Enter list size : ");
	scanf("%d",&n);
	int arr[n];
	
	printf(" Enter %d numbers : ",n);
	for (int i=0; i<n; i++){
	scanf("%d",&arr[i]);
      }
      reverse(arr,n);
      return 0;
  }
  
