/*Write a program that reads radius of circle from user and displays
the area of circle.(By user defined function).*/

#include<stdio.h>

float area(float,float,float);                         //function prototype

float area(float radius, float pi,float ans){       //function definition
	
	printf(" Enter radius: ");
	scanf("%f",&radius);
	return ans=pi*radius*radius;
}
int main(){    
   
      float radius;
       float pi=3.142;
        float ans;                                       //function call
     
	ans=area(radius,pi,ans);
	printf(" Area of circle : %.2f",ans);
	
	return 0;
}



