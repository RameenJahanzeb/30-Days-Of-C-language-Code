/*Write a program that reads number of test cases(T) on first line
and for each T , it scans the integer value(N) from user on new line
and displays the sum of all prime numbers less than the integer
value for each N.*/

#include <stdio.h>

int isPrime(int N);                        //func prototype
int Sum(int N);

int isPrime(int N) {                       //prime func definition
    if (N <= 1)
        return 0;
    for (int i = 2; i * i <= N; i++) {
        if (N % i == 0) {
            return 0;
        }
    }
    return 1;
}
int Sum(int N) {                           //sum func definition
    int sum = 0;
    for (int i = 2; i < N; i++) {
        if (isPrime(i)) {
            sum += i;
        }
    }
    return sum;
}
int main() {                                    //func call
    int T, N;

    printf("Enter the number of test cases: ");
    scanf("%d", &T);

    for (int i = 1; i <= T; i++) {
        printf("Enter a number: ");
        scanf("%d", &N);
        printf("Sum : %d\n\n",Sum(N));
    }
    return 0;
}

