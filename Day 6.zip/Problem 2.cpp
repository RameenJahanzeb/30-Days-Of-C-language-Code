/*Write a program in c to print all factors of the number
entered by user by creating functions.*/

#include<stdio.h>

int factor(int,int);                    //funtion prototype
int num,fact;

int factor(int num, int fact){           //function definition
	
	printf("  Number: ");
	scanf("%d",&num);
	
	printf("  Factors of %d : ",num);
	
	for(int i=1; i<=num; i++){
		if(num%i==0){
			printf("%d ",i);
		}
	}
}
int main(){                               //function call
	
	factor(num,fact);
	return 0;
}
