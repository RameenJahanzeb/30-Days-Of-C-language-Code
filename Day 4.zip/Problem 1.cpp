/*Write a program that takes number from user and displays the
sum of numbers up to number.*/

#include<stdio.h>
int main(){
	int num,sum=0;
	
	printf("Enter Number: ");
	scanf("%d",&num);
	
	for(int i=0; i<=num; i++){
		sum+=i;
	}
	printf("Sum: %d" ,sum);
	
	return 0;
}
