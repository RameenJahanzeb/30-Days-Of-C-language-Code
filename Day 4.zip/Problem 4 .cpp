/*Write a program in C that generates a number between 10 and 20
and asks the user to guess it. Provide some hint whether guess is
too low or too high until user entered the correct guess.*/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(){
	int num1,tries=0;
	srand(time(0));
	int num=rand()%11+10;
	
	printf("Guess the number(10-20): ");
	scanf("%d",&num1);
	//if not correct number
	while(num1!=num){
	if(num1<num){
		printf("Too low! Try Again.\n");
		tries++;
		printf("Guess the number(10-20): ");
			scanf("%d",&num1);
	}
	else {
		printf("Too High! Try Again.\n");
		tries++;
		printf("Guess the number(10-20): ");
			scanf("%d",&num1);
	}
}
	//if correct number
		printf("Bravo! You Guessed the Number in %d tries.",tries);
	
		return 0;
	}
	
	
	
	
