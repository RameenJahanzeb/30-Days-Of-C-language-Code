/*Write a program that swaps two variables entered by user by
using bitwise operators.*/

#include<stdio.h>
int main(){
	int num1,num2;
	
	printf(" Enter Number 1: ");
	scanf("%d",&num1);
	printf(" Enter Number 2: ");
	scanf("%d",&num2);
	
	num1=num1^num2;
	num2=num1^num2;
	num1=num1^num2;
	
	printf(" Number 1: %d\n",num1);
	printf(" Number 2: %d",num2);
	return 0;
}
