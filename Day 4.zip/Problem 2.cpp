//Write a program to print the factorial of the number entered by user.

#include<stdio.h>
int main(){
	int num,factorial=1;
		
	printf("Enter Number : ");
	scanf("%d",&num);
	
	for(int i=1; i<=num; i++){
		factorial*=i;
	}
	printf("Factorial : %d",factorial);
	return 0;
}
