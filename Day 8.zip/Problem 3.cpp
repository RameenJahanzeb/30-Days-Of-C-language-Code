/*Write a program that takes number of tries(T) user wants
in the first line and for each try, it displays the location of
first odd integer(if any) , otherwise displays 0 on new line
among the list of numbers entered by user.*/

#include<stdio.h>
int main(){
	int n;
	int location=0;
	int tries;
	
	printf("Enter Number of tries : ");
	scanf("%d",&tries);
	for (int i=0; i<tries; i++){

	printf("\n\nEnter Number of values : ");
	scanf("%d",&n);
	int arr[n];
	
	printf(" \nEnter %d numbers : ",n);
	for (int i=0; i<n; i++){
	scanf("%d",&arr[i]);
      }
      location=0;
      for(int i=0; i<n; i++){
      	if(arr[i]%2!=0){
      	location=i+1;
      		break;
		  }
	  }
	
	  if(location==0){
	  printf("Location of first odd integer : 0" );
}
else{
	printf("Location of first odd integer : %d",location);
}
printf("\n======================================");
}
}
