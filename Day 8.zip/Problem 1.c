/*Write a program that calculates the sum and average of all
numbers entered by user(Using arrays).*/

#include<stdio.h>
int main(){
	int n;
	int sum=0;
	float avg;
	
	printf("Enter Number of values : ");
	scanf("%d",&n);
	int arr[n];
	
	printf(" Enter %d numbers : ",n);
	for (int i=0; i<n; i++){
	scanf("%d",&arr[i]);
      }
	for(int i=0; i<n; i++){
	  sum+=arr[i];
           }
	     printf(" Sum : %d\n",sum);
	     
	     avg=(float)sum/n;
	     printf(" Average : %.3f",avg);
	     
	     return 0;
	 }
