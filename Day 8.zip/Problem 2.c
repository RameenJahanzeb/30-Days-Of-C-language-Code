/*Write a program that calculates the maximum and
minimum number among the values entered by user.*/

#include<stdio.h>
int main(){
	int n;
	int min;
	int max;
	
	printf("Enter Number of values : ");    //size of arry
	scanf("%d",&n);
	printf(" Enter %d numbers : ",n);
	
	int arr[n];
	for(int i=0; i<n; i++){                 //elements of arry
	scanf("%d",&arr[i]);
      }
      max=arr[0];
    for(int i=0; i<n; i++){
    	if(arr[i]>max){                  //max
    		max=arr[i];
		}
	}
	min=arr[0];
	for(int j=0; j<n; j++){
    	if(arr[j]<min){                 //min
    		min=arr[j];
		}
	}
	printf("Maximum Number : %d\n\n",max);
	printf("Minimum Number : %d\n\n",min);
	
	return 0;
}
