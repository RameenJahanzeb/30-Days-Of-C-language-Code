   /*Write a program that stores the value entered by user in
     integer variable, address of that variable in pointer and
      prints out the pointer address in hexadecimal format,
       octal format and decimal format.*/

#include<stdio.h>
int main(){
	int num;
	int *n;
	n=&num;
	
	printf("\n Enter Number : ");
	scanf("%d",&num);
	
	printf("   %d is stored in my memory location %p(16) , %o(8) and %u(10) of my system.",num,n,n,n);
	
	return 0;
}
