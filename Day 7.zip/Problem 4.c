/*Write a program that scans two integers from user and
displays their HCF and LCM.*/

#include<stdio.h>
int main(){
	 int num1,num2,LCM,HCF;
	 
	 printf("\n  Number 1 : ");
	scanf("%d",&num1);
	printf("  Number 2 : ");
	scanf("%d",&num2);
	//HCF
	if(num1<num2){
		for(int i=1; i<=num1; ++i){
			if(num1%i==0 && num2%i==0){
			    HCF=i;
			}
		}
	}
	else{
		for(int i=1; i<=num2; ++i){
			if(num1%i==0 && num2%i==0){
			    HCF=i;
			}
		}
	}
	 printf("\n  HCF of %d and %d : %d\n",num1,num2,HCF);  
	    //LCM
	    LCM=(num1*num2)/HCF;
	printf("\n  LCM of %d and %d : %d",num1,num2,LCM);	
return 0;	    	
}
