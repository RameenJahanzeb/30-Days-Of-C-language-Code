/*Write a program in c to swap two integers entered by user
without using third variable( By User defined function).*/

#include<stdio.h>

int swap(int *p,int *r);

int main(){
	int num1,num2;
	int *p=&num1,*r=&num2;
	
	printf("\n  Number 1 : ");
	scanf("%d",&num1);
	printf("  Number 2 : ");
	scanf("%d",&num2);
	swap(p,r);
	printf("\n  After Swapping \n\n  Number 1 : %d \n  Number 2 : %d",*p,*r);
	return 0;
}

int swap(int *p,int *r){
	*p=*p+*r;
	*r=*p-*r;
	*p=*p-*r;
	return 0;
}
