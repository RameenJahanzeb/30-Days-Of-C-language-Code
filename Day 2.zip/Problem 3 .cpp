#include<stdio.h>
int main(){
	int num1,num2;
	 
	printf("First Number: ");
	scanf("%d",&num1);
	printf("Second Number: ");
	scanf("%d",&num2);
	
	if(num1==num2){
		printf("  1");
	}
	else{
		printf("  0");
	}
	return 0;
}
