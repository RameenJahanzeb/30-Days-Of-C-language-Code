#include<stdio.h>
int main(){
	int length,width,area;
	
	printf("Enter Length of rectangle = ");
	scanf("%d",&length);
	
	printf("Enter Width of rectangle = ");
	scanf("%d",&width);
	
	area=length*width;
	printf("Area of the rectangle = %d",area);
	
	return 0;
}
