#include<stdio.h>
int main(){
	float num1,num2,num3,num4,num5;
	float sum,average;
	
	printf("Enter Five numbers: ");
	scanf("%f %f %f %f %f",&num1, &num2, &num3, &num4, &num5);
	
	sum=num1+num2+num3+num4+num5;
	average=sum/5;
	
	printf("Sum: %.0f \n",sum);
	printf("Average: %.2f",average);
	
	return 0;
}
